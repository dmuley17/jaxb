package com.multipass.gateway.util;

public final class Constants {
	public static final String PROXY_PROTOCOL = "http";

	public static final String HTTPS_USE_PROXY = "https.proxyUse";
	public static final String HTTPS_PROXY_HOST = "https.proxyHost";
	public static final String HTTPS_PROXY_PORT = "https.proxyPort";

	public static final String HTTP_USE_PROXY = "http.proxyUse";
	public static final String HTTP_PROXY_HOST = "http.proxyHost";
	public static final String HTTP_PROXY_PORT = "http.proxyPort";
	
	public static final String HTTP_CONNECTION_TIME_OUT = "http.ConnectionTimeout";
	public static final int HTTP_CONNECTION_TIME_OUT_DEFAULT_VALUE = 30000;
	
	public static final String HTTP_READ_TIME_OUT = "http.ReadTimeout";
	public static final int HTTP_READ_TIME_OUT_DEFAULT_VALUE = 30000;
}
