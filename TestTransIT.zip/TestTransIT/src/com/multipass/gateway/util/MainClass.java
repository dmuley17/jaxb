package com.multipass.gateway.util;

public class MainClass {
public static void main(String[] args) {
	Environment env=Environment.SANDBOX;
	String request="DN";
	HttpUtility.postData(env, request);
}
}
