package com.multipass.gateway.util;

public enum Environment {
	SANDBOX("https://stagegw.transnox.com/servlets/TransNox_API_Server"),
	PRODUCTION("https://stagegw.transnox.com/servlets/TransNox_API_Server");
	
	private String baseUrl;
	private Environment(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	/**
	 * @return the baseUrl
	 */
	public String getBaseUrl() {
		return baseUrl;
	}
}
