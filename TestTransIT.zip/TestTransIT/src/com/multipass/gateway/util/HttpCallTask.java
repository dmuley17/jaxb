package com.multipass.gateway.util;

import java.io.InputStream;
import java.util.concurrent.Callable;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;


public class HttpCallTask implements Callable<String>{
	Environment env = null;
	String request = null;
	
	/**
	 * Creates task to be called in future for making http call
	 * @param env  Env to point to 
	 * @param request  Http request to send 
	 * @param classType  Expected response type if successful
	 */
    public <T> HttpCallTask(Environment env, String request) {
    	this.env = env;
    	this.request = request;
    }

	@Override
	public String call() throws Exception {
		StringBuilder buffer = new StringBuilder();
		DefaultHttpClient httpCaller = null;
		HttpPost httppost = HttpUtility.createPostRequest(this.env, this.request);
		httpCaller = new DefaultHttpClient();
		
        long startTime = System.currentTimeMillis();
       

        HttpResponse httpResponse = httpCaller.execute(httppost);
		
        
        System.out.println("HTTP Response Code:::"+httpResponse.getStatusLine().getStatusCode());
		if ( null != httpResponse) { 
			if ( null != httpResponse.getStatusLine()) { 
				if ( 200 == httpResponse.getStatusLine().getStatusCode()) {
					HttpEntity entity = httpResponse.getEntity();
					InputStream instream = entity.getContent();
					buffer.append(HttpUtility.convertStreamToString(instream));
				}
			}
		}
		 long endTime = System.currentTimeMillis();
	     System.out.println("That took " + (endTime - startTime) + " milliseconds");
		return buffer.toString();
	}
	
	

}
