package com.multipass.gateway.util;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;


public class HttpUtility {
	static int httpConnectionTimeout = 0;//Environment.getIntProperty(Constants.HTTP_CONNECTION_TIME_OUT);
	static int httpReadTimeout = 0;//Environment.getIntProperty(Constants.HTTP_READ_TIME_OUT);
	
	static {
		
		httpConnectionTimeout = (httpConnectionTimeout == 0 ? Constants.HTTP_CONNECTION_TIME_OUT_DEFAULT_VALUE : httpConnectionTimeout );
		httpReadTimeout = (httpReadTimeout == 0 ? Constants.HTTP_READ_TIME_OUT_DEFAULT_VALUE : httpReadTimeout);
	}
	public static void postData(Environment env, String request) {
		Object response=null;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future future = executor.submit(new HttpCallTask(env, request));
        executor.shutdown(); // Important!
        try {
        	response = future.get();
        	System.out.println("Response :"+response);
		} catch (InterruptedException ie) {
			System.out.println("Interrrupted Exception");
		} catch (ExecutionException ee) {
			System.out.println("ExecutionException");
		}

	}

	public static HttpPost createPostRequest(Environment env, String request) throws URISyntaxException, UnsupportedEncodingException {
		URI postUrl = null;
		HttpPost httpPost = null;
		if(null != request) {
			  postUrl = new URI(env.getBaseUrl());
			  httpPost = new HttpPost(postUrl);
              //set the tcp connection timeout
  			  httpPost.getParams().setIntParameter(HttpConnectionParams.CONNECTION_TIMEOUT, httpConnectionTimeout);
  			  //set the time out on read-data request
  			  httpPost.getParams().setIntParameter(HttpConnectionParams.SO_TIMEOUT, httpReadTimeout);
			  httpPost.setHeader("Content-Type", "text/xml; charset=utf-8");
			  
			  String xmlRequest = 
					  "<Sale>"
			  		+ "<deviceID>**</deviceID>"
			  		+ "<transactionKey>***</transactionKey>"
			  		+ "<cardDataSource>MANUAL</cardDataSource>"
			  		+ "<transactionAmount>100</transactionAmount>"
			  		+ "<cardNumber>4111111111111111</cardNumber>"
			  		+ "<expirationDate>122013</expirationDate>"
			  		+ "<cvv2>999</cvv2>"
			  		+ "<externalReferenceID>16</externalReferenceID>"
			  		+ "</Sale> ";//XmlUtility.getXml(request);
			  httpPost.setEntity(new StringEntity(xmlRequest, HTTP.UTF_8));
		}
		return httpPost;
	}

	public static String convertStreamToString(InputStream is) {
	    String line = null;
		InputStreamReader isr = null;
		BufferedReader reader = null;
	    StringBuilder sb = null;
	    //read the stream
	    try {
			isr = new InputStreamReader(is) ;
			reader = new BufferedReader(isr);
		    sb = new StringBuilder();
	        while ((line = reader.readLine()) != null) {
	            sb.append(line);
	        }
	    } catch (IOException e) {
			//logger.warn(String.format("Exception reading data from Stream: '%s'", e.getMessage()));
	    } finally {

	    	tryClose( reader);
	    	tryClose( isr);
	    	tryClose( is);
	    }
	    
	    return sb.toString();
	}
	private static <T extends Closeable> void tryClose( T closableObject) {
	    if (null != closableObject)
	    {
	    	try {
	    		closableObject.close();
			} catch (Exception e) {
				System.out.println("EXXX");
			}
	    }
	}
}
